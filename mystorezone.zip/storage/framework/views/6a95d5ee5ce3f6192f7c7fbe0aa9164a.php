
<?php $__env->startSection("content"); ?>
<h3 class="text-center text-danger">My Cart zone</h3>

<div class="container my-4" >
<a href="/ordernow" class="btn btn-danger mx-4">Order Now</a>
<div class="row my-4" style="border: 2px solid purple;">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-sm-6">
        <img class="detailimg" src="<?php echo e($item->gallery); ?>" alt="" srcset="">
    </div>
    <div class="col-sm-6"> 
        <h3 class="my-4 text-primary " style="border: 2px solid black;"><?php echo e($item->name); ?></h3>
        <h3 class="my-4 text-primary" style="border: 2px solid black;">Price=<?php echo e($item->price); ?></h3>
        <h4 class="my-4 text-primary" style="border: 2px solid black;"><?php echo e($item->description); ?></h4>
        <h4 class="my-4 text-primary" style="border: 2px solid black;"> Discount=><?php echo e($item->discount); ?></h4>
        <div class="mx-4">
            <a href="/removecart/<?php echo e($item->cart_id); ?>" class="btn btn-primary mx-2">Remove to Cart</a>
            <a href="/ordernow" class="btn btn-danger mx-4">Buy Now</a>
        </div>
    </div> 
    <a href="/">GO BACK</a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<a href="/ordernow" class="btn btn-danger mx-4">Order Now</a>
</div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vikra_9jc6ko1\storesell\resources\views/cartlist.blade.php ENDPATH**/ ?>