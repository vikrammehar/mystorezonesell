
<?php $__env->startSection("content"); ?>
<h3 class="text-center text-danger">Product details </h3>
<div class="container">
<div class="row my-4">
    <div class="col-sm-6">
        <img class="detailimg" src="<?php echo e($products['gallery']); ?>" alt="" srcset="">
    </div>
    <div class="col-sm-6"> 
        <h3 class="my-4 text-primary" style="border:2px solid black;"><?php echo e($products['name']); ?></h3>
        <h3 class="my-4 text-primary" style="border:2px solid black;"><?php echo e($products['price']); ?></h3>
        <h4 class="my-4 text-primary" style="border:2px solid black;"><?php echo e($products['description']); ?></h4>
        <h4 class="my-4 text-primary" style="border:2px solid black;"><?php echo e($products['discount']); ?></h4>
        <div class="mx-4">
           <form action="/add_to_cart" method="POST">
            <input type="hidden" name="product_id" value="<?php echo e($products['id']); ?>">
           <?php echo csrf_field(); ?>
            <button class="btn btn-success my-4">Add to Cart</button>
           </form>
           <a href="/ordernow" class="btn btn-danger mx-4">Buy Now</a>
        </div>
    </div> 
    <a href="/">GO BACK</a>
</div>
</div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vikra_9jc6ko1\storesell\resources\views/detail.blade.php ENDPATH**/ ?>