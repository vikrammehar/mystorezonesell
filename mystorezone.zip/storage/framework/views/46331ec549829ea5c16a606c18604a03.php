
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
  </head>
  <body>
    <h1>Hello vikram</h1>
  </body>
  </html>
<?php /**PATH C:\Users\vikra_9jc6ko1\storesell\resources\views/welcome.blade.php ENDPATH**/ ?>