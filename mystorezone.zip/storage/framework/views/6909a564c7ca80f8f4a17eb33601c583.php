
<?php $__env->startSection("content"); ?>
Search page
<main>
    <h1 class="text-center bg-dark text-warning">Search item</h1>
    <div class="container">
        <div class="row my-4">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-6">
            <img class="detailimg" src="<?php echo e($item['gallery']); ?>" alt="" srcset="">
    </div>
    <div class="col-sm-6"> 
        <h3 class="my-4 text-primary"><?php echo e($item['name']); ?></h3>
        <h3 class="my-4 text-primary"><?php echo e($item['price']); ?></h3>
        <h4 class="my-4 text-primary"><?php echo e($item['description']); ?></h4>
        <h4 class="my-4 text-primary"><?php echo e($item['discount']); ?></h4>
        <div class="mx-4">
            <button class="btn btn-success">Add to Cart</button>
            <a href="/ordernow" class="btn btn-danger mx-4">Buy Now</a>
        </div>
    </div> 
    <a href="detail/<?php echo e($item['id']); ?>">Detail</a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
 </main> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vikra_9jc6ko1\storesell\resources\views/search.blade.php ENDPATH**/ ?>