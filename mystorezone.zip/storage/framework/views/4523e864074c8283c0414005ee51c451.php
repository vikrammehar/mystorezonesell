<footer class="red">
    <h1 class="bg-dark text-danger footer">&copy 2024 Best Quality product zone.All rights reserved.</h1>
</footer><?php /**PATH C:\Users\vikra_9jc6ko1\storesell\resources\views/footer.blade.php ENDPATH**/ ?>