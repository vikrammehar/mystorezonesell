
<?php $__env->startSection("content"); ?>
<h3 class="text-center text-danger text-small">Home page</h3>
<div class="sliderpanel"> 
<div id="carouselExampleInterval" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="carousel-item <?php echo e($item['id']==1? 'active':''); ?>"  data-bs-interval="9000">
      <img src="<?php echo e($item['gallery']); ?>" class="pinker" alt="product" >
      <div class="carousel-caption d-none d-md-block">
        <h5 class="text-warning"><?php echo e($item['name']); ?></h5>
        <h4 class="text-warning"><?php echo e($item['price']); ?></h4>
        <p class="text-warning"><?php echo e($item['description']); ?></p>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</div>

<h1 class="bg-dark text-warning shopitem">Shop Items</h1>
<main>
    <div class="flex1">
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="pink one">
        <img class="img2" src="<?php echo e($item['gallery']); ?>"  alt="product items">
        <h2><a href="detail/<?php echo e($item['id']); ?>"><?php echo e($item['name']); ?></a></h2>
        <h3><mark class="hilight"> <?php echo e($item['discount']); ?> </mark></h3>
        <h4 class="add"><?php echo e($item['price']); ?></h4>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
 </main> 
<?php $__env->stopSection(); ?>
   

<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vikra_9jc6ko1\storesell\resources\views/product.blade.php ENDPATH**/ ?>