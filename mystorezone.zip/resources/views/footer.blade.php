<footer class="red">
    <h1 class="bg-dark text-danger footer">&copy 2024 Best Quality product zone.All rights reserved.</h1>
</footer>